package br.senai.suico.RestauranteX;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestauranteXApplicationTests {

	@Test
	void contextLoads() {
	}

}
