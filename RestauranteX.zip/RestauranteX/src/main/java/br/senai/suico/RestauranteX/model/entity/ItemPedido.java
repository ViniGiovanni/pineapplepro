package br.senai.suico.RestauranteX.model.entity;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import br.senai.suico.RestauranteX.model.dto.ProdutoDto;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Transient;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


 @Entity
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ItemPedido implements Serializable{
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	
    private float desconto;
    private Integer quantidade;
    private float preco;
    
    @JsonIgnore
    @ManyToOne
	@JoinColumn(name="pedido_Id")
	private Pedido pedido;
    
    @JsonIgnore
    @OneToOne
	@JoinColumn(name="produto_Id")
	private Produto produto;
  
    /*
	@Transient
    @JsonIgnoreProperties(ignoreUnknown = true, value = {"produto_Id"})
    private ProdutoDto produtoDto;
*/
	public ProdutoDto getProdutoDto() {
       return produto.toMapperDto();
	}

}
