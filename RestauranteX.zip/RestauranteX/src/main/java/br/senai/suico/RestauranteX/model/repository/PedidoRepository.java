package br.senai.suico.RestauranteX.model.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import br.senai.suico.RestauranteX.model.entity.Pedido;

public interface PedidoRepository extends JpaRepository<Pedido,Long>{	
}
