package br.senai.suico.RestauranteX.model.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import br.senai.suico.RestauranteX.model.entity.Categoria;
import br.senai.suico.RestauranteX.model.entity.Produto;

public interface ProdutoRepository extends JpaRepository<Produto,Long>{	

  
   @Query("Select p from Produtos p inner join p.categoria c where p.quantidade > 0 and c.id = :categoria_id ") 
   public List<Produto> findByCategoriaId(@Param("categoria_id") Long categoria_id);
}
