package br.senai.suico.RestauranteX.model.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ItemPedidoDto {
	private float desconto;
	private Integer quantidade;
	private Long produtoId;
}
