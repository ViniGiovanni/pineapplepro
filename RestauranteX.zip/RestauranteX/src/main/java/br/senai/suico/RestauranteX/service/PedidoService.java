package br.senai.suico.RestauranteX.service;

import java.util.List;
import java.util.Optional;

import br.senai.suico.RestauranteX.model.dto.PedidoDto;
import br.senai.suico.RestauranteX.model.entity.Pedido;


public interface PedidoService {
	public void validarDadosObrigatorios(PedidoDto pedido);
	public Pedido salvar(PedidoDto pedido);
	//public Pedido atualizar(PedidoDto pedido);
	
	public List<Pedido> buscar();
	public List<Pedido> buscarPorClienteId(long clienteId);	
	public Optional<Pedido>  buscarPorId(long id);
}
