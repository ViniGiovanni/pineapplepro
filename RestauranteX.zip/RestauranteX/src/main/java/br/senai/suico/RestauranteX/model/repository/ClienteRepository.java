package br.senai.suico.RestauranteX.model.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import br.senai.suico.RestauranteX.model.entity.Cliente;

public interface  ClienteRepository extends JpaRepository<Cliente,Long> {

	// Querys métodos
	boolean existsByEmail(String emai);
	
	Optional<Cliente>  findByEmail(String email);	
	
	@Query("Select c from Clientes c inner join c.enderecos e   where  c.id = :clienteId and e.ativo = true ")
	Optional<Cliente>  findById2(@Param("clienteId") Long clienteId);	
	
}
