package br.senai.suico.RestauranteX.service.impl;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import br.senai.suico.RestauranteX.exception.RegraNegocioException;
import br.senai.suico.RestauranteX.model.dto.ClienteDto;
import br.senai.suico.RestauranteX.model.dto.ClienteDto2;
import br.senai.suico.RestauranteX.model.dto.LoginDto;
import br.senai.suico.RestauranteX.model.entity.Cliente;
import br.senai.suico.RestauranteX.model.entity.Endereco;
import br.senai.suico.RestauranteX.model.entity.Telefone;
import br.senai.suico.RestauranteX.model.repository.ClienteRepository;
import br.senai.suico.RestauranteX.model.repository.EnderecoRepository;
import br.senai.suico.RestauranteX.model.repository.TelefoneRepository;
import br.senai.suico.RestauranteX.service.ClienteService;

@Service
public class ClienteServiceImpl implements ClienteService {

	private ClienteRepository repository;
	private EnderecoRepository enderecoRepository;
	private TelefoneRepository telefoneRepository;

	public ClienteServiceImpl(ClienteRepository repository, EnderecoRepository enderecoRepository,TelefoneRepository telefoneRepository ) {
		super();
		this.repository = repository;
		this.enderecoRepository = enderecoRepository;
		this.telefoneRepository = telefoneRepository;
	}

	@Override
	public void validarEmail(String email) {
		boolean existe = repository.existsByEmail(email);
		if (existe) {
			throw new ResponseStatusException(HttpStatus.FOUND);
		}
	}

	@Override
	@Transactional(readOnly = true)
	public void validarDadosObrigatorios(Cliente cliente,boolean consistir) {
		if (cliente.getNome() == null || cliente.getNome().trim().equals("")) {
			throw new RegraNegocioException("Informe um nome válido");
		}

		if (cliente.getEmail() == null || cliente.getEmail().trim().equals("")) {
			throw new RegraNegocioException("Informe um email válido");
		}

		
		if ( consistir && cliente.getSenha() == null || cliente.getSenha().trim().equals("")) {
			throw new RegraNegocioException("Informe uma senha válida");
		}
	}

	@Override
	@Transactional
	public Cliente salvar(Cliente cliente) {
		validarDadosObrigatorios(cliente,true);
		validarEmail(cliente.getEmail());

		cliente.setAtivo(true);
		if (cliente.getRoles() == null)
			cliente.setRoles("USER");
		var cli = repository.save(cliente);

		atualizarEnderecos(cliente);

		// cliente.setSenha(passwordEncoder.encode(cliente.getSenha()));
		return cli;
	}

	private void atualizarEnderecos(Cliente cliente) {
		// this.deletarEnderecoPorClienteId(cliente.getId());
		desativarEnderecosByClienteId(cliente.getId());

		var enderecoLst = cliente.getEnderecos();
		if (enderecoLst != null && enderecoLst.size() > 0) {
			enderecoLst.forEach(endClie -> {
				if (endClie.getComplemento() == null) {
					endClie.setComplemento("");
				}
				endClie.setAtivo(true);
				endClie.setCliente(cliente);
				enderecoRepository.save(endClie);
			});
		}
	}

	@Override
	public Cliente buscarPorEmail(String email) {
		var clienteOptional = repository.findByEmail(email);
		if (clienteOptional.isEmpty()) {
			throw new ResponseStatusException(HttpStatus.NOT_FOUND);
		}

		return clienteOptional.get();

	}

	@Override
	public Optional<LoginDto> autenticar(Cliente cliente) {
		Optional<Cliente> result = repository.findByEmail(cliente.getEmail());

		// cliente.setSenha(passwordEncoder.encode(cliente.getSenha()));

		if (result.isPresent()) {
			if (result.get().isAtivo() && result.get().getSenha().equals(cliente.getSenha()) ) {

				LoginDto cli = new LoginDto();
				cli.setId(result.get().getId());
				cli.setNome(result.get().getNome());
				cli.setEmail(result.get().getEmail());
				cli.setRoles(result.get().getRoles());
				cli.setToken("token123");
				return Optional.of(cli);
			} else {
				throw new ResponseStatusException(HttpStatus.BAD_REQUEST);
			}
		} else {
			throw new ResponseStatusException(HttpStatus.NOT_FOUND);
		}
	}

	@Override
	@Transactional
	public Cliente atualizar(ClienteDto2 clienteDto) {
		Objects.requireNonNull(clienteDto.getId());
			
		var ClienteOptional = repository.findById(clienteDto.getId());
		if (ClienteOptional.isEmpty()) {
			throw new ResponseStatusException(HttpStatus.NOT_FOUND);
		}
		var cliente = ClienteOptional.get();
		cliente.setNome(clienteDto.getNome());
		cliente.setEmail(clienteDto.getEmail());
		cliente.setEnderecos(clienteDto.getEnderecos());
		cliente.setAtivo(true);
		
		List<Telefone> lstTelfones = clienteDto.getTelefones();
		lstTelfones.forEach(item ->{ 
		  item.setCliente(cliente);}
				);
		
		cliente.setTelefones(lstTelfones);
		
		validarDadosObrigatorios(cliente,false);
		
		atualizarEnderecos(cliente);
		var cli = repository.save(cliente);
		var totalDel =telefoneRepository.removeAllByCliente(cliente);
		System.out.println("total excluído: "+totalDel);
	  
		return cli;
	}

	private void desativarEnderecos(Cliente cliente) {
		var enderecoLst = cliente.getEnderecos();
		if (enderecoLst != null && enderecoLst.size() > 0) {
			enderecoLst.forEach(endClie -> {
				endClie.setAtivo(false);
				enderecoRepository.save(endClie);
			});
		}
	}

	private void desativarEnderecosByClienteId(Long id) {
		var clienteOptional = repository.findById(id);
		if (clienteOptional.isEmpty()) {
			throw new ResponseStatusException(HttpStatus.NOT_FOUND);
		}

		Cliente cli = clienteOptional.get();

		var listaEnderecos = enderecoRepository.findByCliente(cli);

		listaEnderecos.forEach(ender -> {
			ender.setAtivo(false);
			enderecoRepository.save(ender);
		});
	}

	@Override
	@Transactional
	public void deletar(long id) {
		Objects.requireNonNull(id);

		var clienteOptional = repository.findById(id);
		if (clienteOptional.isEmpty()) {
			throw new ResponseStatusException(HttpStatus.NOT_FOUND);
		}

		try {
			// repository.delete(clienteOptional.get());
			var cliente = clienteOptional.get();
			cliente.setAtivo(false);
			repository.save(cliente);
			desativarEnderecos(cliente);
		} catch (Exception ex) {
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST);
		}
	}

	@Override
	public List<Cliente> buscarTodos() {
		
		return repository.findAll();

	}

	@Override
	public Cliente buscarPorId(long id) {
		var clienteOptional = repository.findById2(id);
		if (clienteOptional.isEmpty()) {
			throw new ResponseStatusException(HttpStatus.NOT_FOUND);
		}

		var cliente = clienteOptional.get();
		//cliente.getEnderecos().removeIf(ende -> !ende.isAtivo());
		return cliente;
	}

	@Override
	public void deletarEnderecoPorClienteId(long id) {
		var enderecosLista = buscarEnderecoPorClienteId(id);
		enderecosLista.forEach(itemEnde -> {
			enderecoRepository.deleteById(itemEnde.getId());

		});
	}

	@Override
	public List<Endereco> buscarEnderecoPorClienteId(long id) {
		Objects.requireNonNull(id);

		var clienteOptional = repository.findById(id);
		if (clienteOptional.isEmpty()) {
			throw new ResponseStatusException(HttpStatus.NOT_FOUND);
		}

		var listaEnderecos = enderecoRepository.findByCliente(clienteOptional.get());

		return listaEnderecos;
	}

}
