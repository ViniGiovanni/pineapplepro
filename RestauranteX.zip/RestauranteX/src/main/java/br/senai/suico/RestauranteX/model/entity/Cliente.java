package br.senai.suico.RestauranteX.model.entity;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import org.hibernate.annotations.Where;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import br.senai.suico.RestauranteX.model.dto.ClienteDto;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity(name = "Clientes")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Cliente {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "nome", nullable = false, length = 100)
	private String nome;

	@Column(name = "email", nullable = false, length = 100)
	private String email;

	//@JsonIgnore
	@Column(name = "senha", nullable = false, length = 500)
	private String senha;

	private String roles;

	private boolean ativo;

	@JsonManagedReference
	@OneToMany(mappedBy = "cliente",fetch = FetchType.EAGER)
	//  @Where(clause = "ativo = true")
	private List<Endereco> enderecos = new ArrayList<Endereco>();

 
    
	@JsonManagedReference
	@OneToMany(mappedBy = "cliente",fetch = FetchType.EAGER,cascade = CascadeType.ALL)
	private List<Telefone> telefones = new ArrayList<Telefone>();

	public ClienteDto toMapperDto() {
		ClienteDto dto = ClienteDto.builder().id(this.getId()).nome(this.getNome()).email(this.getEmail()).ativo(this.ativo).build();
		
		List<Telefone> telefonesLst = new ArrayList<Telefone>();
	     this.getTelefones().forEach( telefone -> {
	    	 telefonesLst.add(telefone) ;
	     });	
	    dto.setTelefones(telefonesLst); 
		return dto;
	}

}
