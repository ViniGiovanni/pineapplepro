package br.senai.suico.RestauranteX.model.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import br.senai.suico.RestauranteX.model.entity.ItemPedido;

public interface ItemPedidoRepository extends JpaRepository<ItemPedido,Long>{	
}
