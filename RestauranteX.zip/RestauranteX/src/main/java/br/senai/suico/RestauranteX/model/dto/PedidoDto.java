package br.senai.suico.RestauranteX.model.dto;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PedidoDto {
	private Long id;
    private Long clienteId;
    private Long enderecoEntregaId;
    private List<ItemPedidoDto> itens;
}
