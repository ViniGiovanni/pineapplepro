package br.senai.suico.RestauranteX.model.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import br.senai.suico.RestauranteX.model.entity.Cliente;
import br.senai.suico.RestauranteX.model.entity.Telefone;

public interface TelefoneRepository extends JpaRepository<Telefone,Long>{	
	Long deleteAllByCliente(Cliente cliente);
	Long removeAllByCliente(Cliente cliente);
}
