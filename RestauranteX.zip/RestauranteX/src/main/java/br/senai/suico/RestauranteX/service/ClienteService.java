package br.senai.suico.RestauranteX.service;

import java.util.List;
import java.util.Optional;

import br.senai.suico.RestauranteX.model.dto.ClienteDto2;
import br.senai.suico.RestauranteX.model.dto.LoginDto;
import br.senai.suico.RestauranteX.model.entity.Cliente;
import br.senai.suico.RestauranteX.model.entity.Endereco;

public interface ClienteService {	
	public void validarEmail(String email);	
	public void validarDadosObrigatorios(Cliente cliente,boolean consistir);
	public Cliente salvar(Cliente cliente);
	public Cliente  buscarPorEmail(String email);		
	public Optional<LoginDto> autenticar(Cliente cliente);
	
	public void deletarEnderecoPorClienteId(long id);
	public List<Endereco> buscarEnderecoPorClienteId(long id);
		
	public Cliente atualizar(ClienteDto2 cliente);
	public void deletar(long id);
	public List<Cliente> buscarTodos();
	public Cliente  buscarPorId(long id);
}