package br.senai.suico.RestauranteX.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import br.senai.suico.RestauranteX.exception.RegraNegocioException;
import br.senai.suico.RestauranteX.model.dto.PedidoDto;
import br.senai.suico.RestauranteX.model.entity.ItemPedido;
import br.senai.suico.RestauranteX.model.entity.Pedido;
import br.senai.suico.RestauranteX.model.repository.ClienteRepository;
import br.senai.suico.RestauranteX.model.repository.EnderecoRepository;
import br.senai.suico.RestauranteX.model.repository.ItemPedidoRepository;
import br.senai.suico.RestauranteX.model.repository.PedidoRepository;
import br.senai.suico.RestauranteX.model.repository.ProdutoRepository;
import br.senai.suico.RestauranteX.service.PedidoService;

@Service
public class PedidoServiceImpl implements PedidoService {

	private PedidoRepository pedidoRepository;
	private ItemPedidoRepository itemPedidoRepository;
	private ClienteRepository clienteRepository;
	private EnderecoRepository enderecoRepository;
	private ProdutoRepository produtoRepository;

	public PedidoServiceImpl(PedidoRepository pedidoRepository, ItemPedidoRepository itemPedidoRepository,
			ClienteRepository clienteRepository, EnderecoRepository enderecoRepository,
			ProdutoRepository produtoRepository) {
		super();
		this.pedidoRepository = pedidoRepository;
		this.itemPedidoRepository = itemPedidoRepository;
		this.clienteRepository = clienteRepository;
		this.enderecoRepository = enderecoRepository;
		this.produtoRepository = produtoRepository;
	}

	@Override
	@Transactional(readOnly = true)
	public void validarDadosObrigatorios(PedidoDto pedido) {

		if (pedido.getItens().size() < 1)
			throw new RegraNegocioException("Nenhum item de pedido registrado");

		pedido.getItens().forEach(item -> {
			if (item.getQuantidade() < 1) {
				throw new RegraNegocioException(String.format("Item de pedido (%s) com quantidade (%d) inválida.",
						item.getProdutoId(), item.getQuantidade()));
			}
			
			var produtoOptional = produtoRepository.findById(item.getProdutoId());
			if (produtoOptional.isEmpty()) {
				throw new RegraNegocioException(String.format("Produto  (%s) não encontrado",item.getProdutoId()));	
			}
			var prod = produtoOptional.get();
			if( item.getDesconto() >( item.getQuantidade() * prod.getPreco())) {
				throw new RegraNegocioException(String.format("Desconto (%.2f)  inválido.",
						item.getDesconto()));
			}
			
			if(  item.getQuantidade() > prod.getQuantidade()) {
				throw new RegraNegocioException(String.format("Quantidade %d acima do estoque.",
						item.getQuantidade()));
			}
		});

	}

	@Transactional
	@Override
	public Pedido salvar(PedidoDto pedidoDto) {
		Objects.requireNonNull(pedidoDto.getClienteId());
		Objects.requireNonNull(pedidoDto.getEnderecoEntregaId());
		
		validarDadosObrigatorios(pedidoDto);
		// validarNome(produto.getNome());

		var clienteOptional = clienteRepository.findById(pedidoDto.getClienteId());
		if (clienteOptional.isEmpty()) {
			throw new ResponseStatusException(HttpStatus.NOT_FOUND,
					"Cliente " + pedidoDto.getClienteId() + " não encontrado.");
		}

		var enderecoOptional = enderecoRepository.findById(pedidoDto.getEnderecoEntregaId());
		if (enderecoOptional.isEmpty()) {
			throw new ResponseStatusException(HttpStatus.NOT_FOUND,
					"Endereço " + pedidoDto.getEnderecoEntregaId() + " não encontrado.");
		}

		Pedido pedido = Pedido.builder().cliente(clienteOptional.get()).enderecoDeEntrega(enderecoOptional.get())
				.instante(new Date()).build();
		
		var pedi = pedidoRepository.save(pedido);
		
		List<ItemPedido> itensPedido = new ArrayList<ItemPedido>();
		pedidoDto.getItens().forEach(itemDto -> {
			ItemPedido item = new ItemPedido();
			item.setDesconto(itemDto.getDesconto());
			item.setQuantidade(itemDto.getQuantidade());
            var produtoOptional =produtoRepository.findById(itemDto.getProdutoId());
            if (produtoOptional.isEmpty()) {
            	throw new ResponseStatusException(HttpStatus.NOT_FOUND,
    					"Produto " + itemDto.getProdutoId() + " não encontrado.");	
            }
            item.setPreco(produtoOptional.get().getPreco());
            item.setProduto(produtoOptional.get());
            
            item.setPedido(pedi);
            itensPedido.add(item);
		});
		
		pedi.setItens(itensPedido);
		
		itemPedidoRepository.saveAll(pedi.getItens());

		return pedi;
	}

/*	
	@Transactional
	@Override
	public Pedido atualizar(PedidoDto pedido) {
		Objects.requireNonNull(pedido.getId());
		// validarDadosObrigatorios(pedido);

		var PedidoOptional = pedidoRepository.findById(pedido.getId());

		if (PedidoOptional.isEmpty()) {
			throw new ResponseStatusException(HttpStatus.NOT_FOUND);
		}
		return pedidoRepository.save(pedido);
	}

	
*/
	@Override
	public List<Pedido> buscar() {
		return pedidoRepository.findAll();
	}

	@Override
	public Optional<Pedido> buscarPorId(long id) {
		return pedidoRepository.findById(id);
	}

	@Override
	public List<Pedido> buscarPorClienteId(long clienteId) {
		return null;
	}

}
