package br.senai.suico.RestauranteX.model.entity;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonBackReference;

import br.senai.suico.RestauranteX.exception.RegraNegocioException;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Transient;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity(name = "Telefones")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Telefone implements Serializable {
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "numero", nullable = false, length = 11)
	private String numero;

	@JsonBackReference
	@ManyToOne
	@JoinColumn(name = "cliente_id")
	private Cliente cliente;

	public String getNumeroFormatado() {
		if (numero.length() < 10 || numero.length() > 11) {
			return "";
		}
		
		return "(" + numero.substring(0, 2) + ") "
				+ (numero.length() == 10 ? numero.substring(2, 6) + "-" + numero.substring(6, 10)
						: numero.substring(2, 7) + "-" + numero.substring(7, 11));
	}

	public void setNumero(String numero) {

		if (numero.length() < 10 || numero.length() > 11) {
			throw new RegraNegocioException("telefone " + numero + " inválido");

		}
		this.numero = numero;
	}
}
