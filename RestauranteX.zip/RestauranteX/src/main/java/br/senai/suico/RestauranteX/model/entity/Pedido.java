package br.senai.suico.RestauranteX.model.entity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import br.senai.suico.RestauranteX.model.dto.ClienteDto;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Transient;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity(name = "Pedidos")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Pedido implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@JsonFormat(pattern = "dd/MM/yyyy HH:mm")
	private Date instante;

	@JsonIgnore
	@JsonManagedReference
	@ManyToOne
	@JoinColumn(name = "cliente_id")
	private Cliente cliente;

	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "endereco_de_entrega_id")
	private Endereco enderecoDeEntrega;

	@OneToMany(mappedBy = "pedido", fetch = FetchType.EAGER)
	private List<ItemPedido> itens = new ArrayList<ItemPedido>();

/*
	@Transient
    @JsonIgnoreProperties(ignoreUnknown = true, value = {"cliente_id"})
    private ClienteDto clienteDto;
*/
	public ClienteDto getClienteDto() {
       return cliente.toMapperDto();
	}
	

	public float getTotalPedido() {
		float total=0;
		for(ItemPedido itemPedido : this.itens) {
			total += itemPedido.getQuantidade() * itemPedido.getPreco() -itemPedido.getDesconto();
		}
       return total;
	}

}
