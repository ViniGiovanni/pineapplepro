# npm install react-icons
# npm install axios
# npm install react-router-dom5.x
