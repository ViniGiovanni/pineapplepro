import '../ModalPedido/carrinho.css'
import './pagamento.css'
import { useState } from 'react'
import { AiOutlineClose } from 'react-icons/ai'
import { MdOutlineAttachMoney } from 'react-icons/md'
import qrcode from '../../assets/qrcode.png'

export default function FormEndereco(props) {
    const [metodoPagamento, setMetodoPagamento] = useState(1)
    
    return (
        <div>
            <div className='carrinho-box'>
                <div className='carrinho-header'>
                    <div>
                        <MdOutlineAttachMoney size={26}></MdOutlineAttachMoney>
                        <h3>Pagamento</h3>
                    </div>
                    <button onClick={() => props.aberto(false)}>
                        <AiOutlineClose></AiOutlineClose>
                    </button>
                </div>


                <div class="modal">
                    <form class="form">
                        <div class="payment--options">
                            <button name="paypal" type="button" onClick={() => setMetodoPagamento(1)}>
                                Cartão de crédito
                            </button>
                            <button name="apple-pay" type="button" onClick={() => setMetodoPagamento(2)}>
                                Dinheiro
                            </button>
                            <button name="google-pay" type="button" onClick={() => setMetodoPagamento(3)}>
                                Pix
                            </button>
                        </div>
                        {metodoPagamento === 1 && (
                            <div class="credit-card-info--form">
                                <div class="input_container">
                                    <label for="password_field" class="input_label">Titular do Cartão</label>
                                    <input id="password_field" class="input_field" type="text" name="input-name" title="Inpit title" placeholder="Nome impresso no cartão" />
                                </div>
                                <div class="input_container">
                                    <label for="password_field" class="input_label">Número do Cartão</label>
                                    <input id="password_field" class="input_field" type="number" name="input-name" title="Inpit title" placeholder="0000 0000 0000 0000" />
                                </div>
                                <div class="input_container">
                                    <label for="password_field" class="input_label">Data de Validade / CVV</label>
                                    <div class="split">
                                        <input id="password_field" class="input_field" type="text" name="input-name" title="Expiry Date" placeholder="01/23" />
                                        <input id="password_field" class="input_field" type="number" name="cvv" title="CVV" placeholder="CVV" />
                                    </div>
                                </div>
                            </div>
                        )}
                        {metodoPagamento === 2 && (
                            <div class="credit-card-info--form">
                                <div class="input_container">
                                    <label for="password_field" class="input_label">Digite com quanto irá pagar</label>
                                    <input id="password_field" class="input_field" type="text" name="input-name" title="Inpit title" placeholder="R$100,00" />
                                </div>
                            </div>
                        )}
                        {metodoPagamento === 3 && (
                            <div class="credit-card-info--form">
                                <span className='qrcode-span'>Total com frete: R${props.totalPedido + 5}</span>
                                <img src={qrcode} className='qrcode-pix'/>
                                <span className='qrcode-span'>Escaneie o QR CODE acima</span>
                            </div>
                        )}

                        <button class="purchase--btn">Finalizar Pedido</button>
                    </form>
                </div>
                <div className='carrinho-footer'>
                    <div>
                        <button onClick={() => props.etapaAtual(2)}>Voltar</button>
                    </div>
                </div>
            </div>

        </div>
    )
}