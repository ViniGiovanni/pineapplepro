import './carrinho.css'
import Carrinho from '../Carrinho'
import FormEndereco from '../FormEndereco'
import { useState } from 'react'
import Pagamento from '../Pagamento'

export default function ModalPedido(props) {
    // const { abrirCarrinho, toggleCarrinho, etapaAtual } = useContext(CarrinhoContext)
    const [etapaAtual, setEtapaAtual] = useState(props.etapaAtual)
    const [totalPedido, setTotalPedido] = useState(0)
    return (
        <div className="">
            <div className='carrinho-container'>
                {etapaAtual === 1 && (
                    <Carrinho
                        aberto={props.estadoCarrinho}
                        lista={props.produtos}
                        adicionar={props.addItem}
                        remover={props.removeItem}
                        limparPedido={props.limparLista}
                        etapaAtual={setEtapaAtual}
                        setarTotal ={setTotalPedido} />
                )}
                {etapaAtual === 2 && (
                    <FormEndereco
                    aberto={props.estadoCarrinho}
                    lista={props.produtos}
                    etapaAtual={setEtapaAtual}/>
                )}
                {etapaAtual === 3 && (
                    <Pagamento
                    aberto={props.estadoCarrinho}
                    etapaAtual={setEtapaAtual}
                    totalPedido={totalPedido}/>
                )}
                
            </div>
        </div>
    )
}