import logo from '../../assets/logo.png'

//import '../DropdownCardapio/button.css'
import './header.css'

import { FiLogOut, FiUser } from "react-icons/fi";

import UserContext from '../../contexts/UserContext'
import React, { useContext, useState } from "react";
import { useHistory, Link } from 'react-router-dom';
import { setAuthToken } from '../../utils/setAuthToken';
import { limparCaches } from '../../utils/limparCaches';

export default function Header() {
    const [user, setUser] = useContext(UserContext);
    const history = useHistory();
    const [mostrarBotao, setMostarBotao] = useState(false)
    
    var usuario = JSON.parse(localStorage.getItem("usuario"));

    setUser(usuario.nome);
    let roles = usuario.roles
    let roleAdmin = roles.includes("ADMIN");
    let roleUser = roles.includes("USER");

    const logout = () => {
        limparCaches();
        setAuthToken();
        setUser('');
        history.push("/")

    }

    function ToggleButton() {
        mostrarBotao === true ? setMostarBotao(false) : setMostarBotao(true)
    }
    
    return (
        <header>
            <div className='menu'>
                <ul className='header-links-box'>
                <li className="ocultar">aaa</li>
               
                <li className='header-links li'><Link to="/home">Home</Link></li>
                    {
                       roleUser && <li className='header-links'><a href="/home#sobre">Sobre</a></li>
                    }              
                    
                    {
                       roleAdmin && <li className='header-links'><Link to="#">Clientes</Link></li>
                    }
                    <li className='header-links'><img src={logo} alt="Logo" /></li>
                    {
                       roleUser && <li className='header-links'><Link to="/contato">Contato</Link></li>
                    }
                    
                    {
                       roleAdmin && <li className='header-links'><Link to="#">Dasboard</Link></li>
                    }
                    {
                       roleUser && <li className='header-links'><Link to="/produtos">Menu</Link></li>
                    }
                    {
                         roleAdmin &&  <li className='header-links'><Link to="#">Pedidos</Link></li>
                    }
                    <li>
                        <button onClick={ToggleButton} className="header-user-button">
                            <FiUser size={22} color='rgb(208, 203, 203)' />
                        </button>
                    </li>
                </ul>
                <div className='header-user'>
                    {mostrarBotao &&
                        <div className='header-user-list'>
                            <span>{user}</span>
                            <ul>
                                <li className='header-links'><Link to="/meuperfil">Editar Perfil</Link></li>
                                {
                                    roleUser && <li className='header-links'>Meus Pedidos</li>
                                }
                                
                                {
                                    roleAdmin && <li className='header-links'><Link to="/categoria">Categorias</Link></li>
                                }
                                {
                                   roleAdmin &&  <li className='header-links'><Link to="/produto/cadastro">Produto</Link></li>
                                }
                                {
                                   roleAdmin &&  <li className='header-links'><Link to="/perfildeacesso">Atribuir Perfil de Acesso</Link></li>
                                }
                                


                                <li>
                                    <button onClick={logout} className="btn-logout">
                                        <FiLogOut size={22} color='#948849' />
                                    </button>
                                </li>
                            </ul>
                        </div>
                    }

                </div>

            </div>
        </header>
    )
}