import '../ModalPedido/carrinho.css'
import { useState, useContext, useEffect } from 'react'
import './endereco.css'
import api from '../../services/api'
import cep from '../../services/cep'
import UserContext from '../../contexts/UserContext'
import { AiOutlineClose, AiFillShop } from 'react-icons/ai'
import { toast } from 'react-toastify'

export default function FormEndereco(props) {
    var usuario = JSON.parse(localStorage.getItem("usuario"));

    const [enderecos, setEnderecos] = useState([]);
    const [endereco, setEndereco] = useState('');
    const [produtos, setProdutos] = useState(props.lista)
    const [exibirForm, setExibirForm] = useState(false)
    const [cepInput, setCepInput] = useState('')
    const [numero, setNumero] = useState('')


    useEffect(() => {
        carregarEndereço();
    },);

    const carregarEndereço = () => {
        api.get(`/api/clientes/enderecos/${usuario.id}`)
            .then(resposta => {
                setEnderecos(resposta.data);
            })
            .catch(error => { console.log(error) })
    }

    const lancarPedido = (pedido) => {
        console.log("pedidodd");
        console.log(pedido);
        api.post("/api/pedidos", pedido)
            .then((response) => {
                toast.success('Esperando o pagamento...')
            })
            .catch((err) => {
                console.log(err)
                toast.error('Não se iluda')
            }
            )
    }

    function finalizarPedido() {
        const produtosDTO = produtos.map((value) => {
            return {
                desconto: 0,
                quantidade: value.qtd,
                produtoId: value.id
            }
        })
        console.log(produtosDTO)
/*
        let pedido = []
        pedido.push({
            clienteId: usuario.id,
            enderecoEntregaId: endereco,
            itens: [...produtosDTO]
        })
        */
        let pedido = {
            clienteId: usuario.id,
            enderecoEntregaId: endereco,
            itens: [...produtosDTO]
        }
        console.log(pedido)
        lancarPedido(pedido)
        props.etapaAtual(3)
    }

    async function preencherForm(e) {
        e.preventDefault()
        cep.get(`${cepInput}/json`)
            .then(resposta => {
                setCepInput(resposta.data)
            })
            .catch(error => { console.log(error) })
        console.log(cepInput)
    }

    return (
        <div>
            <div className='carrinho-box'>
                <div className='carrinho-header'>
                    <div>
                        <AiFillShop size={26}></AiFillShop>
                        <h3>Endereço de Entrega</h3>
                    </div>
                    <button onClick={() => props.aberto(false)}>
                        <AiOutlineClose></AiOutlineClose>
                    </button>
                </div>
                {exibirForm === true ?
                    <form className='form-add-address'>
                        <div>
                            <label>CEP:</label>
                            <input
                                type="text"
                                placeholder="Digite seu cep..."
                                defaultValue={cepInput.cep}
                                onChange={(e) => setCepInput(e.target.value)}
                            />
                            <button className="fillCep" onClick={preencherForm}>
                                Preencher
                            </button>
                        </div>
                        <div>
                            <label>Logradouro:</label>
                            <input
                                type="text"
                                defaultValue={cepInput.logradouro}
                            />
                            <label>Nº:</label>
                            <input
                                type="text"
                                defaultValue={cepInput.numero}
                            />
                        </div>
                        <div>
                            <label>Bairro:</label>
                            <input
                                type="text"
                                defaultValue={cepInput.bairro}
                            />
                        </div>
                        <div>
                            <label>Município:</label>
                            <input
                                type="text"
                                defaultValue={cepInput.localidade}
                            />
                            <label>UF:</label>
                            <input
                                type="text"
                                defaultValue={cepInput.uf}
                            />
                        </div>
                        <button className='btn-send-address'>Adicionar Endereço</button>
                    </form>
                    :
                    <div>
                        <ul>
                            {enderecos.map((value, index) => {
                                return (
                                    <li className='lista-enderecos' key={index}>
                                        <label class="container">
                                            <label class="checkbox-btn">
                                                <label for="checkbox"></label>
                                                <input id={index} type="checkbox" value={endereco} onChange={() => setEndereco(value.id)} />
                                                <span class="checkmark"></span>
                                            </label>
                                        </label>
                                        <div>
                                            <p>{value.logradouro} Nº{value.numero}</p>
                                            <span>{value.bairro}, {value.municipio} - {value.uf}</span>
                                        </div>
                                    </li>
                                )
                            })}
                        </ul>
                        <div className='btn-add-address'>
                            <button onClick={() => setExibirForm(true)}>Adicionar endereço</button>
                        </div>
                    </div>
                }
                <div className='carrinho-footer'>
                    <div>
                        <button onClick={() => props.etapaAtual(1)}>Voltar</button>
                        <button onClick={finalizarPedido}>Pagar</button>
                    </div>
                </div>
            </div>
        </div >
    )
}