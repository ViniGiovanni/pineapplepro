import '../ModalPedido/carrinho.css'
import { AiOutlineClose, AiOutlineShoppingCart } from 'react-icons/ai'
import logo from '../../assets/logo.png'
import { toast } from 'react-toastify';


export default function Carrinho(props) {

    const numberFormat = (value) =>
        new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }
        ).format(value);
        
    const linhas = props.lista.map((item, index) => {

        return (
            <tr key={index}>
                <td>
                    <img src={item.imagem ?
                        item.imagem :
                        process.env.PUBLIC_URL + logo} className="cart-img-item" alt={item.nome} />
                </td>
                <td>{numberFormat(item.preco)}</td>
                <td className='select-qtd'>
                    <button onClick={() => props.remover(item)}>-</button>
                    <label>{item.qtd}</label>
                    <button onClick={() => props.adicionar(item)}>+</button>
                </td>
                <td>{numberFormat(item.preco * item.qtd)}</td>
            </tr>
        )
    })
    const totalPedido = props.lista.reduce((acc, cur) => acc + (cur.qtd * cur.preco), 0);

    return (
        <div>
            <div className='carrinho-box'>
                <div className='carrinho-header'>
                    <div>
                        <AiOutlineShoppingCart size={26}></AiOutlineShoppingCart>
                        <h3>Meu Pedido</h3>
                    </div>
                    <button onClick={() => props.aberto(false)}>
                        <AiOutlineClose></AiOutlineClose>
                    </button>
                </div>



                <table className='table-cart'>
                    <thead>
                        <tr>
                            <th>Item</th>
                            <th>Preço</th>
                            <th>Quantidade</th>
                            <th>Subtotal</th>
                        </tr>
                    </thead>
                    <tbody>
                        {linhas}
                    </tbody>
                </table>


                <div className='carrinho-footer'>
                    <span>Total: R${totalPedido}</span>
                    {props.setarTotal(totalPedido)}
                    <div>
                        <button onClick={props.limparPedido}>Cancelar Pedido</button>
                        <button onClick={()=>props.etapaAtual(2)}>Avançar</button>
                    </div>
                </div>
            </div>

        </div>
    )
}