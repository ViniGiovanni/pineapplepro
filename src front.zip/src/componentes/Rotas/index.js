import React from "react";
import { BrowserRouter, Route } from "react-router-dom";

import CadastroCliente from "../../paginas/cliente/CadastroCliente";
import Login from "../../paginas/Login";
import Home from "../../paginas/Home";
import RouteGuard from "../RouteGuard";
import CadastroCategoria from "../../paginas/categoria/cadastroCategoria";
import ConsultaProduto from "../../paginas/produto/ConsultaProduto";

import CadastroProduto from "../../paginas/produto/CadastroProduto/cadastroProduto";
import MeuPerfil from '../../paginas/MeuPerfil';
import PerfilDeAcesso from '../../paginas/PerfilDeAcesso';
import Contato from '../../paginas/Contato'

export default function Rotas(){
    return(
     
        <BrowserRouter>
            <Route component={Login} path="/" exact/>
            <Route component={Login} path="/login" exact/>
            <Route component={CadastroCliente} path="/cadastrocliente"/>
            <RouteGuard component={CadastroCategoria} path="/categoria"/>
            <RouteGuard component={CadastroProduto} path="/produto/cadastro"/>
            <RouteGuard component={ConsultaProduto} path="/produtos"/>
            <RouteGuard component={MeuPerfil} path="/meuperfil"/>
            <RouteGuard component={PerfilDeAcesso} path="/perfildeacesso"/>
            <RouteGuard component={Home} path="/home"/>
            <RouteGuard component={Contato} path="/contato"/>      
        </BrowserRouter>
       
    )
}