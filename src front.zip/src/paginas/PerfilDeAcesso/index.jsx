import React, { useContext } from "react";
import Context from "../../contexts/UserContext";

import Header from "../../componentes/Header";


export default function PerfilDeAcesso() {
  const [user] = useContext(Context);

  
  return (
    <main>
      <Header/>
    <h1>Módulo  Perfil de Acesso, não implemntado! Aguardando a paciência do Yann</h1>
    </main>
  );
}