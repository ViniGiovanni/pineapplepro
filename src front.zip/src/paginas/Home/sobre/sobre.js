import './sobre.css';

export function Sobre() {
  return (
    <div className='container-sobre' id='sobre'>

      <div className='card-img-sobre'>
      </div>
      <div className='card-sobre '>
        <h4>Nossa História</h4>
        <p>
        Clara sempre foi apaixonada por culinária e sonhava em abrir sua própria hamburgueria. Depois de anos trabalhando como chef em diferentes restaurantes, ela decidiu que era hora de seguir seu sonho. E assim nasceu a sua hamburgueria, a "Pineapple Burguer".

Clara queria que sua hamburgueria fosse diferente de todas as outras, então ela decidiu usar apenas ingredientes frescos e de alta qualidade. Ela usou sua criatividade para criar hambúrgueres com sabores únicos e combinando ingredientes que ninguém havia pensado antes.
        </p>
      </div>     
    </div>

  )
}