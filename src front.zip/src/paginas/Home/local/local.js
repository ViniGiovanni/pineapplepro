import './local.css';
import Local1 from '../../../assets/Banners/Local1.png'
import Local2 from '../../../assets/Banners/Local2.png'
import Local3 from '../../../assets/Banners/Local3.png'

export function Local(){
  return (
    <div className='section-local'>
    <div className='tilte'>
        Nossas Unidades
    </div>
    <div className='container-local' id='unidades'>
      
    <div className='card-local'>
    <div className='card-image'>
        <img src={Local1} alt='local1'/>
        <div className='heading'> Unidade 1 </div>
    <div className='heading'> Rua Pedro Campana, 20 - Vila Mariana
    <div className='heading'> São Paulo - SP</div>
    </div>
    
    </div>
</div>

<div class="card-local">
    <div className='card-image'>
        <img src={Local2} alt='local2'/>
        <div className='heading'> Unidade 2</div>
    <div className='heading'> Rua Vicente Fernandes, 215 - Nova Betânia
    <div className='heading'> Mossoró - RN</div>
     </div>
    </div>
</div>

<div class="card-local">
    <div className='card-image'>
        <img src={Local3} alt='local3'/>
    <div className='heading'> Unidade 3</div>
    <div className='heading'> Rua Tiradentes, 05 - Centro
    <div className='heading'> Caraí -MG </div>
    </div>
    </div>
</div>
</div>
</div>

  )
}