import React, { Component } from 'react'
import ChatBot from 'react-simple-chatbot'
import { ThemeProvider } from 'styled-components'


const theme = {
    background: '#f5f8fb',
    headerBgColor: '#948849',
    headerFontColor: '#fff',
    headerFontSize: '20px',
    botBubbleColor: '#948849',
    botFontColor: '#fff',
    userBubbleColor: '#0cb3c9',
    userFontColor: '#fff',
}

export default class Bot extends Component {
    render() {
        return (
            <ThemeProvider theme={theme}>
                <ChatBot 
                    steps={[
                        {
                            id: "1",
                            message: "Olá, me chamo PineBot e você?",
                            trigger: "2"
                        },
                        {
                            id: "2",
                            user: true,
                            trigger: "3"
                        },
                        {
                            id: "3",
                            message: "Olá {previousValue}, é bom te conhecer!",
                            trigger: "4"
                        },
                        {
                            id: "4",
                            message: "O que você precisa?",
                            trigger: "5"
                        },
                        {
                            id: "5",
                            options: [
                                {value: "s", label: "Sugestões", trigger: "6A"},
                                {value: "r", label: "Reclamações", trigger: "6B"},
                                {value: "v", label: "Vagas", trigger: "6C"},
                                {value: "i", label: "Horários", trigger: "6D"},
                                {value: "t", label: "Telefone", trigger: "6E"},
                                {value: "u", label: "Unidades", trigger: "6F"},
                            ]
                        },
                        {
                            id: "6A",
                            message: "Legal! Me diga sua ideia!",
                            trigger: "6"
                        },
                        {
                            id: "6",
                            user: true,
                            trigger: '7'
                        },
                        {
                            id: "7",
                            message: "Obrigado pela sugestão!",
                            trigger:'10'
                        },
                        {
                            id: "6B",
                            message: "O que aconteceu?",
                            trigger: '8'
                        },
                        {
                            id: "8",
                            user: true,
                            trigger: '9'
                        },
                        {
                            id: "9",
                            message: "Sinto muito! Iremos trabalhar para resolver isso.",
                            trigger:'10'
                        },
                        {
                            id: "6C",
                            message: "Qual vaga você se identifica?",
                            trigger: "selection"
                        },
                        {
                            id: "6D",
                            message: "Seg-Sex: 18h - 00h e Sab-Dom: 16h -00h",
                            trigger: '10'
                        },
                        {
                            id: "6E",
                            message: "Ligue: (11)4002-8922",
                            trigger: '10'
                        },
                        {
                            id: "6F",
                            message: "Rua Vicente Fernandes, 215. Mossoró - RN",
                            trigger: '6F1'
                        },
                        {
                            id: "6F1",
                            message: "Rua Pedro Campanha, 20. São Paulo - SP",
                            trigger: '6F2'
                        },
                        {
                            id: "6F2",
                            message: "Rua Tiradentes, 05. Caraí - MG",
                            trigger: '10'
                        },
                        {
                            id: "selection",
                            options: [
                                {value: "a", label: "Quero ser atendente.", trigger: "7A"},
                                {value: "m", label: "Quero ser motoboy.", trigger: "7B"},
                                {value: "c", label: "Quero ser cozinheiro.", trigger: "7C"},
                                {value: "g", label: "Quero ser garçom.", trigger: "7D"},
                            ]
                        },
                        {
                            id: "7A",
                            message: "Sinto muito, mas não há vagas disponíveis!",
                            trigger: '10'
                        },
                        {
                            id: "7B",
                            message: "Sinto muito, mas não há vagas disponíveis!",
                            trigger: '10'
                        },
                        {
                            id: "7C",
                            message: "Sinto muito, mas não há vagas disponíveis!",
                            trigger: '10'
                        },
                        {
                            id: "7D",
                            message: "Sinto muito, mas não há vagas disponíveis!",
                            trigger: '10'
                        },
                        {
                            id: '10', 
                            message: 'Mais alguma coisa?',
                            trigger: 'selecionar'
                        },
                        {
                            id: 'finalizar',
                            message: 'Adeus!',
                            end: true
                        },
                        {
                            id: 'selecionar', 
                            options: [
                                {value: "s", label: "Sim.", trigger: "4"},
                                {value: "n", label: "Não.", trigger: 'finalizar'},
                            ]
                        },
                    ]}
                />
            </ThemeProvider>
        )
    }
}
