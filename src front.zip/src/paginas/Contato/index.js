import './bot.css';
import Bot from './components/Bot'
import Header from '../../componentes/Header';

function App() {
  return (
    <div>
      <Header />
      <div className="container-bot">
        <h1>Fale Conosco!</h1>
        <Bot />
      </div>
    </div>
  );
}

export default App;
