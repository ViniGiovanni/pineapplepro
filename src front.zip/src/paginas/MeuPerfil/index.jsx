import React, { useEffect, useState } from "react";
import Usuario from '../../models/usuario';
import './perfil.css';
import api from "../../services/api";
import Header from "../../componentes/Header";
import { FiX } from "react-icons/fi";
import { FiEdit2 } from "react-icons/fi";
import { toast } from 'react-toastify';

export default function MeuPerfil() {

  const [nome, setNome] = useState('');
  const [email, setEmail] = useState('');
  const [telefones, setTelefones] = useState([]);
  const [enderecos, setEnderecos] = useState([]);
  // const [cep, setCep] = useState('');
  // const [logradouro, setLogradouro] = useState('');
   const [numero, setNumero] = useState('');
  // const [complemento, setComplemento] = ('');
  // const [bairro, setBairro] = ('');
  // const [municipio, setMunicipio] = useState('');
  // const [uf, setUf] = useState('');
  const [usuario, setUsuario] = useState({});
  const [tituloForm, setTituloForm] = useState('')
  const [showEditUsuario, setShowEditUsuario] = useState(false);
  const [usuarioEditar, setUsuarioEditar] = useState({})

  useEffect(() => {
    carregarUsuario();
  }, []);

 function carregarUsuario() {
    var usuariotemp = JSON.parse(localStorage.getItem("usuario"));
    api.get('/api/clientes/' + usuariotemp.id)

      .then(response => {
        setNome(response.data.nome);
        setEmail(response.data.email);
        setTelefones(response.data.telefones);
        setEnderecos(response.data.enderecos);
        console.log(response.data.enderecos);
        let usuarionew = new Usuario(response.data.id, response.data.nome, "", response.data.email, response.data.roles)
        setUsuario(usuarionew);
      })
      .catch(error => {
        toast.error(error);
      });
  }


  function adicionar(){
    api.post('/api/clientes/' + usuario.id, usuario)
      .then(response => {

        setNumero(response.data.enderecos.numero);
        let usuarionew = new Usuario(response.data.id, response.data.nome, "", response.data.email, response.data.roles)
        setUsuario(usuarionew);
      })
      .catch(error => {
        toast.error(error);
      });
  }

  const abrirAdicao = () => {
    setTituloForm('Adição de telefone')
    setShowEditUsuario(true)
    setNumero('');
    
  }

  function editar(e) {
    e.preventDefault();

    usuario.nome = nome;
    usuario.email = email;
    
    let newtels = []
    telefones.map((item) => (newtels.push({ numero: item.numero })));
    usuario.telefones = newtels;
    usuario.telefones.push({numero: '11999922212'});
    console.log(usuario);

    api.put('/api/clientes/' + usuario.id, usuario)
      .then(response => {

        setNome(response.data.nome);
        setEmail(response.data.email);
        setTelefones(response.data.telefones);
        setEnderecos(response.data.enderecos);
        
        let usuarionew = new Usuario(response.data.id, response.data.nome, "", response.data.email, response.data.roles)
        setUsuario(usuarionew);
        toast.success('Pefil atualizado!')
      })
      .catch(error => {
        toast.error(error);
      });
    
  }

 
  function AlterarTelefone(index, tel) {
    let telefonesClone = [...telefones];
    telefonesClone[index].numero = tel;
    setTelefones(telefonesClone);
  }
  function removerTelefone(index) {
    let telefonesClone = [...telefones];

    if (telefonesClone.length > 1) {

      telefonesClone.splice(index, 1);
      setTelefones(telefonesClone);
      toast.success('Telefone excuido!')
    }
    else {
      toast.warning("É obrigatório pelo menos um telefone de contato.")
    }

  }

  function somenteNumeros(num) {
    var numbers = num.replace(/[^0-9]/g, '');
    return parseInt(numbers);
  }
  return (
    <>
      <Header />
      <main className='mainCadastros'>
        <div className='container-perfil'>
          <form className="form-perfil" onSubmit={editar}>
            
            <div class="user-box">
              <input type="Nome" defaultValue={usuario.nome} onChange={(e) => setNome(e.target.value)} />
              <label>Nome</label>
            </div>
            
            <div class="user-box">
              <input type="email" defaultValue={usuario.email} onChange={(e) => setEmail(e.target.value)} />
              <label>E-mail</label>
            </div>

            <div>
            <label>Telefones:</label>
            <ul className="lista-telefones">
               {telefones.map((value, index)=>{
                return(
                  <div >                    
                  <li className="user-box">
                    <input
                        defaultValue={value.numero} onBlur={(e) => AlterarTelefone(index, e.target.value)} maxLength="11"
                      onKeyUp={(e) => e.target.value = somenteNumeros(e.target.value)}>
                      </input>
                     </li>
                   <button type="button" className="btn-telefone" onClick={() => removerTelefone(index)}> <FiX color="white" size={15}></FiX>
                   </button>
                  </div>                  
                )
              })}
            </ul>
            </div>
 
          <center>
              <button type="submit" className='form-btn'>Editar</button></center>
          </form>
        </div>
      </main>
    </>
  );
}