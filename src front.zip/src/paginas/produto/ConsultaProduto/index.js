import React, { useContext, useEffect, useState } from "react";
import api from "../../../services/api";
import Context from "../../../contexts/UserContext";
import Header from "../../../componentes/Header";
import ModalPedido from '../../../componentes/ModalPedido'
import logo from '../../../assets/logo.png'
import './produto.css';
import { AiOutlineShoppingCart } from 'react-icons/ai'
import { toast } from "react-toastify";


export default function ConsultaProduto() {
  const [user] = useContext(Context);
  const [produtos, setProdutos] = useState([]);
  const [produtosCarrinho, setProdutosCarrinho] = useState([]);
  const [categoriaId, setCategoriaId] = useState(3);
  const [abrirCarrinho, setAbrirCarrinho] = useState(false)
  const [etapaAtual, setEtapaAtual] = useState(1)
  const [pedido, setPedido] = useState([])

  useEffect(() => {
    carregarProduto(categoriaId);
  }, [categoriaId]);

  const carregarProduto = (categoriaId) => {

    api.get(`/api/produtos/categoria/${categoriaId}`)
      .then(resposta => {
        setProdutos(resposta.data);
      })
      .catch(error => { console.log(error) })
  }

  const atualizaCategoria = (obj, categoriaId) => {
    setCategoriaId(categoriaId);

    const collection = document.getElementsByClassName("menuCate");
    for (let i = 0; i < collection.length; i++) {
      collection[i].classList.remove("selected");
    }

    obj.target.classList.add("selected");

  }

  //função para add item no carrinho
  function addToCart(item) {
    const cloneProdutosCarrinho = [...produtosCarrinho]    
    const contem = cloneProdutosCarrinho.find( (unidade) => unidade.id === item.id)
    if(!contem){
        cloneProdutosCarrinho.push({ 
            id: item.id,
            imagem: `data:image/jpeg;base64,${item.files.data}`,
            qtd: 1, 
            preco: item.preco
        })
    }else{
        contem.qtd += 1
    }
    setProdutosCarrinho(cloneProdutosCarrinho)
    toast.success("Item adicionado no carrinho")
    // console.log(produtosCarrinho)
  }

  function removeFromCart(produto) {
    const cloneProdutosCarrinho = [...produtosCarrinho]
    const item = cloneProdutosCarrinho.find((unidade) => unidade.id === produto.id)

    if (item.qtd > 0) {
      item.qtd -= 1;
      setAbrirCarrinho(cloneProdutosCarrinho)
    } else {
      const carrinhoFiltrado = cloneProdutosCarrinho.filter((product) => {
        return product.qtd > 0
      })
      setProdutosCarrinho(carrinhoFiltrado)
    }
    toast.error("Item removido")
    console.log(cloneProdutosCarrinho)
  }
  const limparPedido = () => {
    setProdutosCarrinho([])
  }

 
  return (
    <div>
      <Header></Header>
      <main className="mainProduto">

        <nav>
          <ul className="cardapio-list-links">

            <li className="selected menuCate" onClick={(e) => atualizaCategoria(e, 3)} >Hambúrguers</li>
            <li className="menuCate" onClick={(e) => atualizaCategoria(e, 4)}>Porções</li>
            <li className="menuCate" onClick={(e) => atualizaCategoria(e, 1)}>Bebidas</li>
            <li className="menuCate" onClick={(e) => atualizaCategoria(e, 2)}>Sobremesas</li>
            <li>
              <AiOutlineShoppingCart size={22} color="white" onClick={() => setAbrirCarrinho(true)}></AiOutlineShoppingCart>
            </li>
          </ul>
        </nav>


        <section className="cardapio-container">
          {produtos.map((item) => {
            return (
              <article className="card">

                <img src={item.files ?
                  `data:image/jpeg;base64,${item.files.data}` :
                  process.env.PUBLIC_URL + logo} className="card-img-item" alt={item.nome} />
                <div className="card-info">
                  <p className="text-title">{item.nome}</p>
                  <p className="text-body">R${item.preco}</p>
                  <button className="card-button-item" onClick={() => addToCart(item)}>Adicionar</button>
                </div>
              </article>
            )
          })}
        </section>
      </main>

      {abrirCarrinho &&
        <ModalPedido
          estadoCarrinho={setAbrirCarrinho}
          produtos={produtosCarrinho}
          addItem={addToCart}
          removeItem={removeFromCart}
          limparLista={limparPedido}
          etapaAtual={etapaAtual}/>
      }
    </div>

  );
}


