export const Mensagens= {
    UsuarioESenhaInvalida: 'Invalid User and Password!',
    ErroGenerico: 'ops! ocorreu um erro:\n',
    EmailESenhaObrigatorio: 'Informe o email e a senha!',
  }