export default class Usuario{
    constructor(id,nome,token,email,roles,ativo){
        this.id = id;
        this.nome = nome;
        this.token = token;
        this.email= email;
        this.roles=roles;
        this.ativo=ativo;
    }
    
}