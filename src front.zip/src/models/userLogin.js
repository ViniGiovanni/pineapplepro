export default class UserLogin{
    constructor(email,senha){      
        this.email = email;
        this.senha = senha;
    }
    
}