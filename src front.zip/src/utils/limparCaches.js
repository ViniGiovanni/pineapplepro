export  const limparCaches = () =>
{
    localStorage.removeItem("usuario");
}